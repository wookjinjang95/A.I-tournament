# myTeam.py
# ---------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

from captureAgents import CaptureAgent
import random, time, util
from game import Directions
import game
from util import nearestPoint

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
               first = 'DummyAgent', second = 'DummyAgent'):
  """
  This function should return a list of two agents that will form the
  team, initialized using firstIndex and secondIndex as their agent
  index numbers.  isRed is True if the red team is being created, and
  will be False if the blue team is being created.

  As a potentially helpful development aid, this function can take
  additional string-valued keyword arguments ("first" and "second" are
  such arguments in the case of this function), which will come from
  the --redOpts and --blueOpts command-line arguments to capture.py.
  For the nightly contest, however, your team will be created without
  any extra arguments, so you should make sure that the default
  behavior is what you want for the nightly contest.
  """

  # The following line is an example only; feel free to change it.
  return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class DummyAgent(CaptureAgent):
  """
  A Dummy agent to serve as an example of the necessary agent structure.
  You should look at baselineTeam.py for more details about how to
  create an agent as this is the bare minimum.
  """

  def registerInitialState(self, gameState):
    """
    This method handles the initial setup of the
    agent to populate useful fields (such as what team
    we're on).

    A distanceCalculator instance caches the maze distances
    between each pair of positions, so your agents can use:
    self.distancer.getDistance(p1, p2)

    IMPORTANT: This method may run for at most 15 seconds.
    """

    '''
    Make sure you do not delete the following line. If you would like to
    use Manhattan distances instead of maze distances in order to save
    on initialization time, please take a look at
    CaptureAgent.registerInitialState in captureAgents.py.
    '''
    CaptureAgent.registerInitialState(self, gameState)

    '''
    Your initialization code goes here, if you need any.
    '''

  ################
  # Main Methods #
  ################

  def chooseAction(self, gameState):
    """
    Picks among actions with highest Q(s,a) same one as in baseline Team.
    """
    # If the value returns smaller eval deems better
    actions = gameState.getLegalActions(self.index)
    actionList = []
    qValuesList = []
    for action in actions:
      if action is not 'Stop':
        actionList.append(action)
        currentState = self.getCurrentObservation()
        successorState = gameState.generateSuccessor(self.index, action)
        qValue = self.evaluate(currentState, successorState, action)
        qValuesList.append(qValue)
        maxValue = max(qValuesList)
        maxIndex = qValuesList.index(maxValue)
        bestAction = actionList[maxIndex]
    #print ("Best Action:", bestAction)
    return bestAction

  def evaluate(self, currentState, successorState, action):
    # action is the action taken to get to the successorState
    """
    Uses a gameState and an action.
    Returns value to choose action.
    """
    qVal = 0
    features = self.getFeatures(currentState, successorState, action)
    weights = self.getWeights(currentState, action)
    qVal += features['closestFood'] * weights['closestCapsule']
    qVal += features['closestCapsule'] * weights['closestCapsule']
    qVal += features['enemyDistance'] * weights['enemyDistance']
    #if qVal == float("-inf"):
    #    print qVal
    return qVal


  def getFeatures(self, currentState, successorState, action):
    """
    Places characteristics in counter data.
    Things to calculate every move.
    """
    # Modify values returned by the functions to create a meaning
    # These values get multiplied by the weights to get an evaluation
    # EX) Food is a distance closest to 1. Either find a value for it
    # or check if the action taken gets you closer to the closest food?
    features = util.Counter()
    #features['successorScore'] = self.getScore(successor)
    features['closestFood'] = self.getClosestFood(currentState, successorState)
    #features['closestEnemy'] = self.getApproximateEnemy(currentState)
    features['closestCapsule'] = self.getClosestCapsule(currentState, successorState)
    features['enemyDistance'] = self.getEnemyDistance(currentState, successorState)
    return features

  def getWeights(self, gameState, action):
    """
    Returns a dict of values that deem how important a charateristic is.
    """
    # Holds a dict of weights for features. Change these to reflect importance.
    return {'closestFood': 2.0, 'closestCapsule': 1.0, 'enemyDistance': -1.0}

  ####################
  # HELPER FUNCTIONS #
  ####################

  """
  List of Characters to Compute:
  1) Get closest food - closest path to other side
  2) Get Noise - approximate position of enemies
  3) Get Capusle - While invulnerable, eat as much food as can
            while always moving towards noise (chase opponent if found)
  """
  def getClosestFood(self, currentState, successorState):
    # Variables needed for computation
    foodList = self.getFood(currentState).asList()
    myState = successorState.getAgentState(self.index)
    myPos = myState.getPosition()
    closestFoodDist = float("inf")
    for food in foodList:
      if self.getMazeDistance(myPos, food) < closestFoodDist:
        closestFoodDist = self.getMazeDistance(myPos, food)
    foodFactor = 1.0 - float(closestFoodDist)/75.0
    #foodFactor = foodFactor * 1
    #print("Food:", foodFactor)
    return foodFactor

  def getClosestCapsule(self, currentState, successorState):
    capsules = self.getCapsules(currentState)
    curr = successorState.getAgentState(self.index).getPosition()
    #if capsules is []:
      #return 0
    #print capsules

    minimum_distance = float("inf")
    for capsule in capsules:
        distance = self.getMazeDistance(curr, capsule)
        if distance < minimum_distance:
            minimum_distance = distance

    #print minimum_distance
    if not capsules:
      #print 0
      return 0

    capsuleFactor = 1 - float(minimum_distance)/100.0
    capsuleFactor = capsuleFactor * 1
    #print ("capsule:", capsuleFactor)
    return capsuleFactor

  def getApproximateEnemy(self, gameState, index):
    """#####################################
        Edited Code:
            My plan is to check whether the next move is going to be
            trapped or not. If it's trapped and noise is less than 4,
            (4 is just my estimate distance) then it will return -inf
            because you will die automatically if you go into that trapped
            area. The trapped function is at "calculateTrapped" function.
    """
    values = gameState.getAgentDistances()
    team = self.getTeam(gameState)
    index = team.index(index)
    #print values[index]
    #print index
    return values[index]

  def getEnemyDistance(self, currentState, successorState):
    distance_away_from_enemy = self.getApproximateEnemy(successorState, self.index)
    if distance_away_from_enemy < 2:
      return float("-inf")
    elif distance_away_from_enemy < 6:
      if self.calculateTrapped(successorState, currentState):
        return float("-inf")
    return distance_away_from_enemy

  def calculateTrapped(self, successorState, currentState):
      """
            To know whether you are going to be trapped or not,
            I said that if possible actions in successorState has
            one legal action and taking that action brings back to
            the currentState position, then you know you are trapped.
            However, this doesnt calculate if the trapped space is
            bigger, not just one spot.
      """
      actions = successorState.getLegalActions(self.index)
      actions.remove('Stop')
      #print actions
      if len(actions) == 1:
          next_successor_state = successorState.generateSuccessor(self.index, actions[0])
          if next_successor_state.getAgentState(self.index).getPosition() == currentState.getAgentState(self.index).getPosition():
              return True
      return False
